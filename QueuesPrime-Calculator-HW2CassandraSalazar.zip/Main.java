public static void main(String[] args) {
  Scanner scanner = new Scanner(System.in);
  System.out.print("Please enter an upperbound: ");
  int n = scanner.nextInt();
  Sieve sieve = new Sieve(n);
  sieve.primesTo(n);

  if (n < 2) { // if it is an illegal argument
    throw new IllegalArgumentException("n cannot be less than 2!!!");
}
