// Import the Math library to use the sqrt function
import java.lang.Math;

// Define a class called Sieve
public class Sieve {
	
	// Define a constructor for the Sieve class
	private int n;
	
	// Define a constructor for the Sieve class that takes an integer argument called n
	public Sieve (int n) {
		this.n = n;
	}
	
	// Define a method called primeTo that takes an integer argument called n
	public void primeTo(int n) {

		// Create a queue to store the numbers to be checked for primality
		ArrayQueue<Integer> num = new ArrayQueue<>();
		for (int i = 2; i <= n ; i++) {
			// Add each number from 2 to n to the queue
			num.enqueue(i);
		}
		
		// Create a queue to store the prime numbers found
		ArrayQueue<Integer> primes = new ArrayQueue<>();
		
		// Start with the first number in the queue
		int p = num.first();
		
		// Add the first number to the list of primes
		primes.enqueue(p);
		
		// Calculate the square root of the input number
		double SQUARE = Math.sqrt(n);
		
		// Loop through the numbers in the queue until p is greater than the square root of n
		while (p <= (SQUARE)) {
			// Create a temporary queue to store the numbers not divisible by p
			ArrayQueue<Integer> temporary = new ArrayQueue<>();
			
			// Loop through the numbers in the queue
			while(!num.isEmpty()) {
				// Dequeue the next number in the queue
				int temp= num.dequeue();
				// If the number is not divisible by p, enqueue it in the temporary queue
				if (temp % p != 0) 
					temporary.enqueue(temp);
			}
		
			// Set the queue of numbers to the temporary queue
			num = temporary;
			
			// Dequeue the next number in the queue and set it as p
			p = num.dequeue();
			
			// Add the new value of p to the list of primes
			primes.enqueue(p);
		}
		
		// Add any remaining in the queue to the list of primes
		while(!num.isEmpty()) {
			primes.enqueue(num.dequeue());
		}
		
		// Print the list of prime numbers
		while(!primes.isEmpty()) {
			System.out.print(primes.dequeue() + " ");
		}
    System.out.print("Primes up to "+ n+ "are:");
    while(!primes.isEmpty()){
      System.out.println(primes.dequeue()+" ");
    }
	}
} 
