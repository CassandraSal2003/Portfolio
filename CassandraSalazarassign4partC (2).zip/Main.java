/*Name: Cassandra Salazar
Date: 11/14/22
Program: Create a hang man game. Use methods, array, and loops to create the game. The user must guess the letter for the word and if they get all of it right, they win. If they don't get the word right and exceed the chances, then add body parts to hang man.   
*/

import java.io.*;
import java.util.*;
import java.net.*;
public class Main
{
//if user gets a letter wrong, then add body parts to hang man

public static void printHangMan(int wrong){
  if (wrong==1){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|");
    System.out.println("|");
    System.out.println("|");
    System.out.println("|");
  }
  else if (wrong==2){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|      |");
    System.out.println("|");
    System.out.println("|");
    System.out.println("|");
    System.out.println("______");
 }
  else if (wrong==3){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|     /|");
    System.out.println("|");
    System.out.println("|");
    System.out.println("|");
 }
  else if (wrong==4){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|     /|\\");
    System.out.println("|");
    System.out.println("|");
    System.out.println("|");
 }
  else if (wrong==5){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|     /|\\");
    System.out.println("|     /");
    System.out.println("|");
    System.out.println("|");
 }
  else if (wrong==6){
    System.out.println("|-------");
    System.out.println("|     ***");
    System.out.println("|     *O*");
    System.out.println("|     /|\\");
    System.out.println("|     / \\");
    System.out.println("|");
    System.out.println("|");
 }
  
} 
//cant convert string to char. use char array instead of string 
public static void printarray(char []array ){
  for (int i=0; i<array.length; i++){
    System.out.print(array[i]);
  }
}

public static void main(String[] args) throws Exception
{
	//open URL and read through it 
	String URLstring="https://cs.nyu.edu/~odeh/resources/python/animals.txt";
  URL ur1 = new URL (URLstring);
	Scanner sc = new Scanner(ur1.openStream());
  Scanner input=new Scanner(System.in);
  String animal="";
	while (sc.hasNextLine())
	//System.out.println(sc.nextLine());
  //concatenate the animals 
  animal+=sc.nextLine()+",";
  
  String [] myarray= animal.split(",");
  String[] array2 = new String[10];//declaring array with 10
  Random rand = new Random();
  //for loop
  for (int i=0; i<10; i++) {
    //random num out of 75 because there are 74 words
    int r = rand.nextInt(75);
    //pushing out random word into array 2
    array2[i]=myarray[r];
  
}

    char [] user= new char[array2[0].length()];
  //printing the hyphens before guessing
  for (int i=0; i< array2[0].length(); i++){
    //replacing with hyphen
    //double quotations is string and single quotes is character
    user[i]='_';
  }

  printarray(user);
  //if the user input contains a letter from the random word, then print the letter. Or else, print hyphen.
  int wrong=0;
  boolean correct=  true;
  while (correct){
    //need to obtain character from user 
  
  System.out.println("Enter a letter: ");
  String guessLetter= input.nextLine(); 
 
  //use what the user guesses
  //converts it to a character
  //storing the letter
  char guess= guessLetter.charAt(0);
  
  if (!array2[0].contains(guessLetter)){
      wrong+=1;
      printHangMan(wrong);
    }
  for (int i=0; i< array2[0].length(); i++){
    if (guess==(array2[0].charAt(i))){
      //if guess is right, we swap the hyphens with a letter
      user[i]=array2[0].charAt(i);
      
    }
    else{
      //continue next iteration of the for loop
     continue;
    }

    //make a for loop where it checks all the characters if entered all characters then they win 
    String answer="";
     //loop through each letter in correct answer  
    for (int j = 0; j < user.length; j++){ //check each letter
      answer+= user[j];         
//if the user input is the same as the random word, then "you win!"
    }
        if (answer.equals(array2[0])){
            System.out.print("You win!");
            correct= false;
        }   
  }
    printarray(user);
    System.out.println();
    
//if the word doesn't contain the letter guess, then we print the hang man. if everything is wrong (6 times) then game over.
    
    if (wrong==6){
      correct=false;
      System.out.println("GAME OVER. The correct word was "+ array2[0]);
    }
  }
  
}
}


