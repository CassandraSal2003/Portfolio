//Cassandra Salazar
//cs6560 - Data Structures
//Assignment: HW 2 - Postfix

import java.lang.Math; 
import java.util.*;

public class Main {

  public static void main(String[] args) {
    // Create a new instance of the StackImpl class
    StackImpl i = new StackImpl();
    
    // Create a new instance of the Scanner class to read input from the user
    Scanner sc= new Scanner(System.in); 
    
    // Prompt the user to enter an infix expression
    System.out.print("type your infix expression: ");  
    
    // Read the infix expression from the user
    String str= sc.nextLine();  
    
    // Convert the infix expression to postfix notation
    String con = i.infixToPostfix(str);
    
    // Print the postfix expression to the console
    System.out.print("converted to postfix: ");
    String prin = i.infixToPostfix(str);
    System.out.println(prin);
  
    // Evaluate the postfix expression and print the result to the console
    System.out.print("answer is ");
    System.out.println(i.postfixToEvaluation(con)); 
  }

}
