import java.util.*;

class StackImpl {

  // Helper function to evaluate x^y using Math.pow
  public int power(int x, int y) {
    return (int) Math.pow(x, y);
  }

  // Function to evaluate postfix expression
  public int postfixToEvaluation(String s) {
    Stack<Integer> st = new Stack<Integer>();
    int x = 0, y = 0;
    char ch[] = s.toCharArray();
    for(char c: ch) {
      if(c >= '0' && c <= '9') {
        // Push integer into stack
        st.push(x*10 + (c - '0'));
      } else if (c == '^') {
        // Pop two values from the top of the stack and compute power using helper function
        y = st.pop();
        x = st.pop();
        st.push(power(x, y)); // push the result of x^y into the stack
      } else {
        // Pop two values from the top of the stack and apply the operator
        y = st.pop();
        x = st.pop();
        switch(c) {
          case '+':
            //if "+" push addition and break 
            st.push(x+y);
            break;
          case '-':
            //if "-" push subtraction and break
            st.push(x-y);
            break;
          case '*':
            //if "*" push multiplication and break
            st.push(x*y);
            break;
          case '/':
            //if "/" push division and break
            st.push(x/y);
            break;
        }
      }
    }
    // Return the final result
    return st.pop();
  }
  
  // Function to convert infix expression to postfix expression
  public String infixToPostfix(String s) {
    Stack<Character> st = new Stack<Character>();
    String postfix = "";
    char ch[] = s.toCharArray();
    
    for(char c: ch) {
      if(c != '+' && c != '-' && c != '*' && c != '/' && c != '(' && c != ')' && c != '^') {
        postfix = postfix + c;
      } else if (c == '(') {
        st.push(c);
      } else if (c == ')') {
        while(!st.isEmpty()) {
          char t = st.pop();
          if(t != '(') {
            postfix = postfix + t;
          } else {
            //if opening bracket is missing, its an error so break 
            break;
          }
        }
      } else if(c == '+' ||c == '-' ||c == '*' ||c == '/' || c == '^') {
        if(st.isEmpty()) {
          st.push(c);
        } else {
          while(!st.isEmpty()) {
            char t = st.pop();
            if(t == '(' || getPriority(t) <  getPriority(c)) {
              st.push(t);
              break;
            } else {
              postfix = postfix + t;
            }
          }
          st.push(c);
        }
      }
    }
    while(!st.isEmpty()) {
      postfix = postfix + st.pop();
    }
    return postfix;
  }
  
  // Helper function to determine operator priority
  public int getPriority(char c) {
    if(c == '+' || c == '-') {
      return 1;
    } else if (c == '*' || c == '/') {
      return 2;
    } else if (c == '^') {
      return 3; // "^" has the highest priority
    } else {
      return 0;
    } 
  }
  
}
