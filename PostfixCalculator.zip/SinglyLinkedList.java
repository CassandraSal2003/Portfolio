// Define the Node class with data and next fields
class Node{
  int data; // holds the data of the node
  Node next; // holds the reference to the next node in the linked list
}

// Define the StackLinked class
class StackLinked {
  Node front; // holds the reference to the top element in the stack
  
  // Method to create a new node with the given value
  public Node getNewNode(int val) {
    Node a = new Node();
    a.data = val;
    a.next = null;
    return a;
  }
  
  // Method to add an element to the top of the stack
  public void push(int val) {
    // If the stack is empty, create a new node and set it as the top
    if(front == null) {
      front = getNewNode(val);
      return;
    }
    
    // Otherwise, create a new node and set it as the new top
    Node t = getNewNode(val);
    t.next = front;
    front = t;
  }
  
  // Method to remove and return the top element from the stack
  public int pop() {
    // If the stack is empty, return the minimum integer value and print a message
    if(front == null) {
      System.out.println("Stack is Empty");
      return Integer.MIN_VALUE;
    }
    
    // Otherwise, remove and return the top element
    int t = front.data;
    front = front.next;
    return t;
  }
  
  // Method to return the top element of the stack without removing it
  
  public int top() {
    if(front == null) {
      System.out.println("Stack is Empty");
      return Integer.MIN_VALUE;
    }
    
    return front.data;
  }
}
