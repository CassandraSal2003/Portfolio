class Stack {
  private int maxSize; // represents the maximum size of the stack
  private char[] stackArray; // an array to store the elements in the stack
  private int top; // represents the index of the topmost element in the stack

  public Stack(int size) { // constructor to create a new stack with a given size
    maxSize = size;
    stackArray = new char[maxSize]; // initialize the stackArray with the given size
    top = -1; // set top to -1 since there are no elements in the stack initially
  }

  public void push(char ch) { // method to push an element onto the top of the stack
    if(top == maxSize - 1) { // check if the stack is already full
      System.out.println("Stack Overflow"); // print an error message
      return; // exit the method
    }
    top++; // increment top to point to the next index
    stackArray[top] = ch; // add the new element to the top of the stack
  }

  public char pop() { // method to remove and return the topmost element from the stack
    if(top == -1) { // check if the stack is already empty
      System.out.println("Stack Underflow"); // print an error message
      return ' '; // return a blank space as a default value
    }
    char ch = stackArray[top]; // get the topmost element from the stack
    top--; // decrement top to point to the previous index
    return ch; // return the topmost element
  }

  public char peek() { // method to return the topmost element without removing it from the stack
    if(top == -1) { // check if the stack is empty
      System.out.println("Stack is empty"); // print an error message
      return ' '; // return a blank space as a default value
    }
    return stackArray[top]; // return the topmost element
  }

  public boolean isEmpty() { // method to check if the stack is empty
    return top == -1; // return true if top is -1 
  }
}


class TheConverter {
  public String infixToPostfix(String s) { 
    //method to convert an infix expression to a postfix expression
    Stack st = new Stack(s.length()); 
    //create a new stack with a size equal to the length of the input expression
    String postfix = ""; 
    //initialize an empty string to store the postfix expression
    char ch[] = s.toCharArray(); 
    // convert the input expression to a character array
    
    for(char c: ch) { 
      //loop through each character in the input expression
      if(c != '+' && c != '-' && c != '*' && c != '/' && c != '(' && c != ')') { 
        //if the character is not an operator or parenthesis
        postfix = postfix + c; // append the character to the postfix expression
      } else if (c == '(') { // if the character is an opening parenthesis
        st.push(c); //push it onto the stack
      } else if (c == ')'){
        while(!st.isEmpty()) {
          char t = st.pop();
          if(t != '(') {
            postfix = postfix + t;
          } else {
            break;
          }
        }
      } else if(c == '+' ||c == '-' ||c == '*' ||c == '/') {
        if(st.isEmpty()) {
          st.push(c);
        } else {
          while(!st.isEmpty()) {
            char t = st.pop();
            if(t == '(') {
              st.push(t);
              break;
            } else if(t == '+' || t == '-' || t == '*' || t == '/') {
              if(getPriority(t) <  getPriority(c)) {
                st.push(t);
                break;
              } else {
                postfix = postfix + t;
              }
            }
          }
          st.push(c);
        }
      }
    }
    while(!st.isEmpty()) {
      postfix = postfix + st.pop();
    }
    return postfix;
  }
  
  public int getPriority(char c) {
    if(c == '+' || c == '-') {
      return 1;
    } else if(c == '*' || c == '/') {
      return 2;
    } else {
      return -1;
    }
  }
}



