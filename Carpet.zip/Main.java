public class Main{

   public static void main(String[] args){
     //int col, row;
     int col, row;
     int num= 10;
    
     //top row %
     for (row=1; row<=19; row++){
       System.out.print("%");
     }
      System.out.println(" ");

     //diamond shape *
       for (row = 1; row <= num; row++){
           for (col = 1; col <= num-row; col++){
               System.out.print(" ");
           }
         for (col=1; col<= row * 2 -1 ; col++){
            System.out.print("*");  
         }
         System.out.println();
       }
    
       for(row=num -1; row>0; row--){
           for (col=1; col<=num-row; col++){
            System.out.print(" ");
          }
         for (col = 1; col <= row * 2 - 1; col++)
          { 
				System.out.print("*");
         }
         System.out.println(); 

    }
     //bottom row %
       for (int i=1; i<=19; i++){
       System.out.print("%");
     }
      System.out.println(" ");

    //make 3 spaces in front and *** to make checkerboard
    for (int j= 0; j<7; j++){
      System.out.print("   ***");
    
    }
    System.out.println("");
    for (int a = 0; a<7; a++){
      
      System.out.print("   ***");
    }
     System.out.println("");
     
     //do opposite as before; *** and 3 spaces to create checkerboard effect and squares!!
    for (int b=0; b<7; b++){
      System.out.print("***   ");
    }
     System.out.println("");
     
     for (int c=0; c<7; c++){
      System.out.print("***   ");
     }

     
  }  
}
