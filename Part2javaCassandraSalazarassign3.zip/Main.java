import java.util.Scanner;
//variable im manipulating (int/String) 
//change if not array 
//returning result 
class Main {
  
  //method
  //int[]=array (returning array) and then if want to return int or str you put in static
  
//dec to bin method
  // initialize a variable that is being maniuplated throaught each code. do for each (num_to_num(int/string num))
  public static int[] dec_to_bin(int dec){
      int[] bin_zero={0,0,0,0};
    String result = "";
    //make an index of i that starts at 3.
      int i=3;
    //changed from str to dec
      while (dec != 0) {
        int remainder = dec % 2;
        bin_zero[i]=remainder;
        i--;
        result = remainder + result; // find remainder add to result
        dec /= 2; // dividing number by 2. storing value
      }
    //return method bin_zero
      return bin_zero;
    
  }


//dec to oct method
  public static String dec_to_oct(int str){
    String result1 = "";
      //base of 8 and use mod
      while (str >= 0) {
        int remainder = str % 8;
        result1 = remainder + result1;
        str /= 8;

        if (str == 0 && remainder == 0) {
          break;

        
        }
        

      }
    //return method for each number converison
return result1;
  }



//dec to hex method 
  public static String dec_to_hex(int str){   
    String result2 = "";
     // create an array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    //base 16 using mod
      while (str > 0) {
        int remainder = str % 16;
        result2 = hex[remainder] + result2;
        str /= 16;

        // putting extra zeros

        if (remainder >= 0 && remainder <= 9) {
          result2 = "000" + result2;

        
        }
       
      }
     return result2;
  }

  
//bin to dec method
  public static int bin_to_dec(String input){
  //String decimal = "";
      int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 2;  
      }
      
    return decimal;
  }


// bin to hex
  public static String bin_to_hex(String input){
     int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 2;

      }
      //overwrite input
      input = decimal;
      
      String result2 = "";
      // array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

      while (input > 0) {
        int remainder = input % 16;
        result2 = hex[remainder] + result2;
        input /= 16;

        // putting extra zeros

        if (remainder >= 0 && remainder <= 9) {
          result2 = "000" + result2;


      return result2;
        }
      }

    
//bin to oct
public static String bin_to_oct(String input){    
  int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 2;

      }
      //overwrite input
      input = decimal;
      
      String result1 = "";

      while (input >= 0) {
        int remainder = input % 8;
        result1 = remainder + result1;
        input /= 8;

        if (input == 0 && remainder == 0) {
          break;
        }
      return result1;
      }


// oct to dec
  public static int oct_to_dec(String input){    
    int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 8;
      }
    return decimal;
  }

  
//oct to bin
  public static int[] oct_to_bin(String input){
    int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 8;
      }
    //overwrite input
      input = decimal;
      String result = "";
  int[] bin_zero={0,0,0,0};
    //make an index of i that starts at 3.
      int i=3;
    while (input != 0) {
        int remainder = input % 2;
      bin_zero[i]=remainder;
        i--;
        result = remainder + result; // find remainder add to result
        input /= 2; // dividing number by 2. storing value
      }
      return bin_zero;
  }

  
//oct to hex
  //changed str to input 
  public static int oct_to_hex(String input){
  int decimal = 0;
      int start = 1;
      for (int i = input.length() - 1; i >= 0; i--) {
        if (input.charAt(i) == '1')
          decimal += start;
        start = start * 8;
      }
   //overwrite input
      input = decimal;
      String result2 = "";
      // array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

      while (input > 0) {
        int remainder = input % 16;
        result2 = hex[remainder] + result2;
        input /= 16;

        // putting extra zeros

        if (remainder >= 0 && remainder <= 9) {
          result2 = "000" + result2;

        }

      }
    return result2;
  }



  

// hex to dec
  public static int hex_to_dec(int decimal){
  // array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

      int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
      int multiply=1;
      int decimal = 0;
      for (int i = input.length()-1; i>=0; i--) {
        // finding match from input value and hex array
        
        for (int j = 0; j <= hex.length-1; j++){
          // index
        
          if (input.charAt(i) == hex[j]){
           decimal += multiply*numbers[j];
            multiply=multiply*16;
            break;  
            }
        }
        return decimal;
      }

    
//hex to bin
    public static int[] hex_to_bin(int decimal){
      // array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

      int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
      int multiply=1;
      int decimal = 0;
      for (int i = input.length()-1; i>=0; i--) {
        // finding match from input value and hex array
        
        for (int j = 0; j <= hex.length-1; j++){
          
          // index
        
          if (input.charAt(i) == hex[j]){
          
           decimal += multiply*numbers[j];
            multiply=multiply*16;
            break;
            }
        }
      }
//overwrite input
      str = decimal;          
    String result = "";

      // asking user input. convert to bin find remainder of num. divide str until its
      //MAKE AN ARRAY OF 4 ZEROS  
      int[] bin_zero={0,0,0,0};
    //make an index of i that starts at 3.
      int i=3;
      
      while (str != 0) {
        int remainder = str % 2;
        bin_zero[i]=remainder;
        i--;
        result = remainder + result; // find remainder add to result
        str /= 2; // dividing number by 2. storing value
      }
        return bin_zero;
      }


//hex to oct 
  public static int hex_to_oct(int decimal){
      // array:
      char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

      int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
      int multiply=1;
      int decimal = 0;
      for (int i = input.length()-1; i>=0; i--) {
        // finding match from input value and hex array
        
        for (int j = 0; j <= hex.length-1; j++){
          // index
        
          if (input.charAt(i) == hex[j]){
          
           decimal += multiply*numbers[j];
            multiply=multiply*16;
            break;

          
            }
        }
      }
  //overwrite input
      str = decimal;  
     String result1 = "";

      while (str >= 0) {
        int remainder = str % 8;
        result1 = remainder + result1;
        str /= 8;

        if (str == 0 && remainder == 0) {
          break;
        }
        //return method
      return result1;
      }
      
    
//MAIN FUNCTION
public static void main(String[] args) {
    
    Scanner user = new Scanner(System.in); // Create scanner object

    // input user
    System.out.print("Enter the name of the number system to convert from: bin, or dec, or oct or hex: "); // Read user
      // input
    String num = user.next(); // Read user input

    System.out.print("Enter number as a String: ");
    String input = user.next();
    System.out.print("Enter the name of the number system you want to convert to: bin, or dec, or oct or hex: ");
    String num2 = user.next();

//num conversions 
   if (num.equals("dec") && num2.equals("bin")) {
      String result = "";

     //store the output of the method dec to bin
     int[] store_bin= dec_to_bin(Integer.parseInt(input));
     System.out.print("The result is: ");
      //reading array from index 0 to array length.
      for (int j=0; j < store_bin.length; j++){
        System.out.print(store_bin[j]);
      }
  }

//STORE EACH NUMBER CONVERSION AND PRINT THE RESULTS FOR EACH
  if (num.equals("dec") && num2.equals("oct")) {
      String result1= "";
      //store the output of the method dec to oct
     String store_oct= dec_to_oct(Integer.parseInt(input));
      
      System.out.print("The result is: " + store_oct);
  
  }

  if (num.equals("dec") && num2.equals("hex")) {
      String result2 = "";
      String store_hex= dec_to_hex(Integer.parseInt(input));
     System.out.print("The result is: " + store_hex);
    }

  if (num.equals("bin") && num2.equals("dec")){
      //String decimal="";
      int store_dec= bin_to_dec(input);
      System.out.print("The result is: " + store_dec);
    }
if (num.equals("bin") && num2.equals("hex")) {
      String result2 = "";
      int store_hex= bin_to_hex(Integer.parseInt(input));
      
      System.out.print("The result is: " + result2);
  
  }

    if (num.equals("bin") && num2.equals("oct")) {
      String result1 = "";
      int store_oct= bin_to_oct(Integer.parseInt(input));
     System.out.print("The result is: " + result1);
    }

    if (num.equals("oct") && num2.equals("dec")) {
      int store_dec= oct_to_dec(Integer.parseInt(input));
      System.out.print("The result is: " + decimal);

    if (num.equals("oct") && num2.equals("bin")) {
      int[] store_bin= oct_to_bin(Integer.parseInt(input));
      System.out.print("The result is: ");
      //reading array from index 0 to array length.
      for (int j=0; j < store_bin.length; j++){
        System.out.print(store_bin[j]);
      }
  }

    if (num.equals("oct") && num2.equals("hex")) {
      String result2 = "";
      int store_oct= oct_to_hex(Integer.parseInt(input));
     System.out.print("The result is: " + result2);
    }

    if (num.equals("hex") && num2.equals("dec")) {
      int store_dec= hex_to_dec(Integer.parseInt(input));
      System.out.print("The result is: " + store_dec);
    }

    if (num.equals("hex") && num2.equals("bin")) {
    int[] store_bin= hex_to_bin(Integer.parseInt(input));
     System.out.print("The result is: ");
      //reading array from index 0 to array length.
      for (int j=0; j < store_bin.length; j++){
        System.out.print(store_bin[j]);
      }
  }

      if (num.equals("hex") && num2.equals("oct")) {
        String result1 = "";
        int store_oct= hex_to_oct(Integer.parseInt(input));
        System.out.print("The result is: " + result1);
    }

    



  
}

}