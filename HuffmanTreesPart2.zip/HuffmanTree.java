import java.util.*;

public class HuffmanTree{
  HuffmanNode root;

  //This constructor sets this.root to huff
  public HuffmanTree (HuffmanNode huff){
    this.root=huff;
}
  /**
   * Returns the root of the Huffman tree.
   */
  public HuffmanNode getRoot() {
    return root;
  }
  //public void printLegend(). This calls printLegend(root, ""), which calls private void printLegend(HuffmanNode t, String s), a recursive method that works as follows: If (t.letter.length() > 1) i.e., t contains multiple characters, then t is NOT a leaf node, so we recursively call printLegend() on its left child using string s + "0", and recurse on t’'s right child using string s + "1". If t.letter is a single character, then t is a leaf node, and we print out (t.letter+"="+s);
  public void printLegend(){
    printLegend(root, "");
  }
  private void printLegend(HuffmanNode t, String s){
    if (t.letter.length() > 1){
      printLegend(t.right, s + "0");
      printLegend(t.left , s + "1");
    }
    if(t.letter.length()==1){
      System.out.println(t.letter + "=" + s);
    }
  }
  
  // takes a String for the legend containing our input (letter & frequency data). The letters and frequencies are all one line with spaces as separators. (You may assume each separator is a single space).
  public static BinaryHeap legendToHeap(String legend){
    BinaryHeap binHeap = new BinaryHeap();
    String[]element= legend.split(" ");
    for (int i=0; i< element.length; i+=2){
      String letter = element[i];
      Double freq=Double.parseDouble(element[i+1]);
      binHeap.insert(new HuffmanNode (letter, freq));
    }
    return binHeap;
  }
  
  //When we have only one element left in the heap, we remove it, and create a new HuffmanTree object with root set to the removed object.
  //Create a single HuffmanNode for each letter and its frequency, and insert each of these into a new BinaryHeap

  public static HuffmanTree createFromHeap(BinaryHeap b){
    //While the Binary Heap has more than one element
    while(b.getSize()!=1){
      //Remove the two nodes with minimum frequency
      HuffmanNode node1=(HuffmanNode)b.deleteMin();
      HuffmanNode node2=(HuffmanNode)b.deleteMin();
//Create a new HuffmanNode with those minimum frequency nodes as children (using the the HuffmanNode constructor with left and right nodes as parameters) and insert that node into the BinaryHeap.
      HuffmanNode mix=new HuffmanNode(node1, node2);
      mix.left=node1;
      mix.right=node2;
      b.insert(mix);
      
    }
    //The BinaryHeap’s only element will be the root of the Huffman Tree. Pass this node into the HuffmanTree constructor and return the result
    HuffmanTree tree=new HuffmanTree((HuffmanNode)b.findMin());
    return tree;
  }
}
