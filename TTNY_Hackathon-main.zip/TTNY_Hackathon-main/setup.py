import methods

# Customers
methods.createCustomer("John", "Doe", 100)
methods.createCustomer("Mary", "Anne", 620)


# Merchants
methods.createMerchant("H&M", "Clothing")
methods.createMerchant("Walmart", "Food")
methods.createMerchant("Food Bazaar", "Food")
methods.createMerchant("TicketMaster", "Entertainment")
methods.createMerchant("Con Edison", "Utilities")