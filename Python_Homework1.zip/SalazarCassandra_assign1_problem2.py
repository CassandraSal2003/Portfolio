#Cassandra Salazar 2/3/2022 section 11. Cars code. 
#I input the commands to ask the reciever to enter four specific cars. Each car number represents the car the reciever entered. I then printed the order the way the reciever entered the cars, and backwards.

car1 = input("Please enter car #1:")
car2 = input("Please enter car #2:")
car3 = input("Please enter car #3:")
car4 = input("Please enter car #4:")

print ("Here are the cars in the order entered:")
print (car1, ", ", car2, ", ", car3, ", ", car4, sep = "")
print ("Here are the cars in reverse order:")
print (car4, "; ", car3, "; ", car2, "; ", car1, sep = "")

