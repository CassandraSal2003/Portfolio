#Cassandra Salazar 2/3/2022 section 11, Conversion code. I made the conversions to 3 quarts using basic math. I made quarts eaqual to 3 and then used the other forms of measurement and multiplied it by the necessary amount in order to be equal to 3 quarts. I used the print option to state the amounts of each form of measurement. I used the code '>20' to make the spaces to replicate the format of the problem.  

line= ("-")*40
print(line)
print ("Quarts to Other Fluid Volume Units")
print (line)
quarts=3.00
pint=quarts*2
cups=pint*2
oz=cups*8
gal=quarts*0.25
lit=oz*0.0295735
mill= lit*1000
tbs=oz*2
two_dec_rounded = round(2839.0559999999996, 2)
two_dec_rounded_lit = round( 2.839056, 2)
quarts=3.00
print(format("quarts:", '>20'), end='')
print (format(quarts, '>20'))
print(format("tablespoons:", '>20'), end='')
print (format(tbs, '>20'))
print(format("ounces:", '>20'), end='')
print (format(oz, '>20'))
print(format("cups:", '>20'), end='')
print (format(cups, '>20'))
print(format("pints:", '>20'), end='')
print (format(pint, '>20'))
print(format("gallons:", '>20'), end='')
print (format(gal, '>20'))
print(format("milliliters:", '>20'), end='')
print (format(two_dec_rounded, '>20'))
print(format("liters:", '>20'), end='')
print (format(two_dec_rounded_lit, '>20'))