/*Name: Cassandra Salazar
Date: 12/4/22
Program: Create a battleship game. Print "#" if attempt is wrong and "X" if you hit one of the parts of the ship. Once you hit all parts, you win the game and it terminates. The game does not end until you win.   
*/
import java.util.Random;
import java.util.Scanner;
class Main {
  //make count variables to keep track of the number of hits and attempts made in the game. 
  static int hits=0;
  static int attempts=0;
  
  public static void main(String[] args) {
    //make a board that is 10x10   
    final int SHIP_SIZE = 10;
    char[][] game_board = new char[SHIP_SIZE][SHIP_SIZE];

    //use this to make length of 1 ship equal to 4 boxes
    int[][] four_ships = new int[4][2];
    
    Random_ships(four_ships);

    while (hits!=4){
      printBoard(game_board);
    
    //store value of the guess in game board; it will access the values 
      user_input(game_board, four_ships); 
      System.out.println("You sunk the ship. You win! Game over. The number of attempts you made is: "+ attempts);
      printBoard(game_board);
    }
  }  
  
  //print the board by making a method and aligning the letters with the pattern of the board
  //value thats stored in game board ij, hits and misses 
  public static void printBoard(char[][] game_board){
	
    System.out.println("   A   B   C   D   E   F   G   H   I   J");
    System.out.println(" +---+---+---+---+---+---+---+---+---+---+");
    
    //use a for loop to print the side of the board
		for(int i = 0; i < game_board.length; i++) {
			System.out.print(i+ "|");
			for(int j = 0; j < game_board[i].length; j++) {
      //assigning the empty spaces in the board to equal 0.
        if (game_board[i][j]==0){
          System.out.print("   ");
        }
        else {
          
				  System.out.print(" "+game_board[i][j]+" ");
        }
          System.out.print("|");
        //
			}
      System.out.println();
      System.out.println(" +---+---+---+---+---+---+---+---+---+---+");
      
		}
  }
        
  public static void Random_ships(int[][] four_ships){
    Random random = new Random();
    //VERTICAL
    //random integer range from 0 to 1 
    int orientation= random.nextInt(2);
    //setting the first random point
    if (orientation==0){
      
      int y=random.nextInt(7);
      
      int x=random.nextInt(10);
      
      int[] xy = {x, y};
      four_ships[0] = xy;

      //incrementing random point by 3 more below or above
      for (int i=1; i<4; i++){
        int []array=new int[2];
        
        y=y+1;
        
        //assigning 0 and 1 and putting them in a new nested array
        //storing x and y in four_ships 2d array
        array[0]=x;
        array[1]=y;
          
        four_ships[i] = array;
      }

    //HORIZONTAL
    }
    else {
      int y=random.nextInt(10);
      
      int x=random.nextInt(7);
      
      int[] xy = {x, y};
      four_ships[0] = xy;

      //incrementing 3 more below or above
      
      for (int i=1; i<4; i++){
        int []array=new int[2];
        
        x=x+1;
        
        //assigning 0 and 1 and putting them in a new nested array
        //storing x and y in four_ships 2d array
        array[0]=x;
        array[1]=y;
          
        four_ships[i] = array;
      }
      
    }
  }

  public static void user_input(char[][] user, int[][] four_ships){
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a coordiante to target (e.g. A1): ");
    String shot = input.nextLine();
    //Scanner.close();

    int index_1=0;
    //taking first letter
    //Each letter represents a number
    //use if statements to make each letter represent a number
    if (shot.charAt(0)=='A'){
      
    }
    else if (shot.charAt(0)=='B'){
       index_1=1;
    }
    else if (shot.charAt(0)=='C'){
       index_1=2;
    }
    else if (shot.charAt(0)=='D'){
       index_1=3;
    }
    else if (shot.charAt(0)=='E'){
       index_1=4;
    }
    else if (shot.charAt(0)=='F'){
       index_1=5;
    }
    else if (shot.charAt(0)=='G'){
       index_1=6;
    }
    else if (shot.charAt(0)=='H'){
       index_1=7;
    }
    else if (shot.charAt(0)=='I'){
       index_1=8;
    }
    else if (shot.charAt(0)=='J'){
       index_1=9;
    }

    //Vertical input at 1. Parse the integers. Nothing has to be converted since they are already numbers. 
    int vertical=Integer.parseInt(String.valueOf(shot.charAt(1)));

    for (int i=0; i<four_ships.length; i++){
      //compare two values in each sub array of four_ships
      int []array_1=four_ships[i];
  
      //if index_1 and vertical are equal, then the user hit the ship and print "X". Increment the number of hits made to count them.
      if (index_1==array_1[0] && vertical==array_1[1]){
        hits++;
        user[vertical][index_1] = 'X';
      
      //else if you don't hit the ship, print a "#" and add the number of attempts made.   
      }
      else {
        attempts++;
        user[vertical][index_1]='#';
      }
    }
      
  }
    
}

