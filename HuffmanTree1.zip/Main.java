//Cassandra Salazar 
//cs6560
//Huffman Trees Homework 
import java.util.Scanner;
//SAMPLE CODE: A 20 E 24 G 3 H 4 I 17 L 6 N 5 O 10 S 8 V 1 W 2

class Main {
  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    //print
    System.out.println("Enter Info: ");
    String legend=sc.nextLine();

    //heap legendtoHeap method
    BinaryHeap heap=HuffmanTree.legendToHeap(legend);
   
    heap.printHeap();

    //tree createFromHeap method
    HuffmanTree node= HuffmanTree.createFromHeap(heap);

    node.printLegend();
  }
}